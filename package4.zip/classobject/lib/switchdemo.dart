class switch_demo2{
	void Sdemo2(String name)
	{
		first:
		while(true){
		switch(name)
		{
			case 'apple':
				print("apple");
				continue first; 
			case 'banana':
				print("banana");
				break;
			case 'orange':
				print("orange");
				break;
			default:
				print("this fruit is not listed");
		}
		}
	}
}