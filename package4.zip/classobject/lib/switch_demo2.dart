class switch_demo2{
	void Sdemo2(String name){
	outerloop:while(true){
        switch(name)
		{
			case 'apple':
				print("apple");
				name="End";
				continue outerloop; 
			case 'banana':
				print("banana");
				break;
			case 'orange':
				print("orange");
				break;
			default:
				print("this fruit is not listed");
		}
		break;
		}
	}
}