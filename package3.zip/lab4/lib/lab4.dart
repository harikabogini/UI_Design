class switch_demo{
String Scase(String color){
	var x= (switch(color){
		'red'||'Red'||'RED' =>'this is red',
		'blue'||'Blue'||'BLUE'=>'this is blue',
		'green'||'Green'||'GREEN'=>'this is green',
		'black'||'Black'||'BLACK'=>'this is black',
				 _    =>'no listed',
	});
	return(x);
	}
}
