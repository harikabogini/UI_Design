class switch_demo{
	void sdemo(String name)
	{
		switch(name)
		{
			case 'apple':
				print("apple");
				break;
			case 'banana':
				print("banana");
				break;
			case 'orange':
				print("orange");
				break;
			default:
				print("this fruit is not listed");
		}
	}	


}